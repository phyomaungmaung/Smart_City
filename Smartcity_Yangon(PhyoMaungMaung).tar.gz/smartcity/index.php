<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- Bootstrap CSS -->
  <link rel="icon" type="image/png" href="image/yg.png">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/860068da85.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style.css">

  <title>Smart city</title>
</head>
<body>

  <!-------------------------------------Menu Navbar--------------------------------->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
      <a href="index.php" class="navbar-brand ml-3" >Yan<span style="color:#EFBAA1">Gon</span></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu" 
      aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse"></div>
      <div class="collapse navbar-collapse" id="navbarMenu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
              <a href="#aboutmyanmar" class="nav-link">About Myanmar</a>
          </li>
          <li class="nav-item">
              <a href="project.php" class="nav-link">Projects</a>
          </li>
          <li class="nav-item">
            <a href="payment.php" class="nav-link">Payments</a>
          </li>
          <li class="nav-item">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
          <li class="nav-item">
            <a href="about.php" class="nav-link">About Us</a>
          </li>
        </ul>
                <?php
                    include('connection/connection.php');
                    if(isset($_POST['sub'])){
                      $sub_email = $_POST['email'];
                      if(mysql_query("INSERT INTO subscribe VALUES('','$sub_email')")){

                        echo "<script>alert('Thank for your Subscribe')</script>";
                      }
                      else{
                        echo "<script>alert('Fail your subscribe')</script>";
                      }
                    }

                ?>
              <form class="form-inline my-2 my-lg-0" method="post">
              
                  <input type="email" name="email" value="" placeholder="Email" required>
                  <button type="submit" name="sub" id="" class="btn btn-danger" btn-lg btn-block">SUBSCRIBE</button>
              </form>
            </div>
          </div>
        </div>
        </form>
      </div>
    </nav>
  </header>

  <!------------------------------main view------------------------------------->
  <main>
    <div class="container-fluid p-0">
      <div class="site-content">
        <div class="d-flex justify-content-center">
          <div class="d-flex flex-column">
            <h1 class="site-title">Yangon Smart City</h1>
            <p class="site-desc">Thai firm to develop $1bn industrial smart city in Yangon</p>

            <div class="d-flex flex-row">
              <a href="about.php"><input value="Click Here" class="btn site-btn1 px-1 py-3 mr-4 btn-dark"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
<!---------------------------------------About Myanmar-------------------------------->
    <div class="section-1" id="aboutmyanmar">
      <div class="container text-center">
        <h1 class="heading-1">About Myanmar</h1>
        <p class="para-1">The official name of the country is the Republic of the Union of Myanmar. 
          In 1989, the name was changed from Burma to Myanmar. Both names are derived from the majority ethnic group, the Bamar – Myanmar being the formal, literary term, and Burma the colloquial, everyday term
        </p>
        <div class="row justify-content-center">
          <div class="col-md-4">
            <div class="card">
              <img src="image/history.jpeg" alt="historyofmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">History</h4>
                <p class="card-text">Myanmar has a long history and its greatness dates back to the early 11th Century 
                  when King Anawrahta unified the country and founded the First Myanmar Empire in Bagan.
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/national.jpg" alt="nationalofmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">National Symbols</h4>
                <p class="card-text">
                The yellow, green and red colours included as background colours indicate the three-coloured flag which was applied magnificently in the period of struggle for the independence of Myanmar
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/geography.jpg" alt="geographyofmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">Geography</h4>
                <p class="card-text">
                  Myanmar, a republic in South-East Asia, bounded on the north by Tibet Autonomous Region of China; on the east by China, Laos, and Thailand; on the south by the Andaman Sea and the Bay of Bengal
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
        </div>
          <br>
        <br>
        <div class="row justify-content-center">
          <div class="col-md-4">
            <div class="card">
              <img src="image/people.jpg" alt="peopleofmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">People & Society</h4>
                <p class="card-text">The Republic of the Union of Myanmar has a population of over 51 million (2014 Census). The major racial groups are Bamar, 
                  Kachin, Kayah, Kayin, Chin, Mon, Rakhine and Shan.People & Society
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/culture.jpg" alt="cultureofmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">Culture & Heritage</h4>
                <p class="card-text">
                  Myanmar lies on the crossroad of two of the world’s great civilizations – China and India – but its culture is neither 
                  that of India nor that of China exclusively, but a blend of both interspersed with Myanmar native traits 
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/travel.jpg" alt="travelmyanmar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">Travel Myanmar</h4>
                <p class="card-text">
                  Mingalabar is a word of welcome and a wish for good fortune. This single word signifies the inherent nature of the people of Myanmar, 
                  offering world-class hospitality and always wishing others well.
                </p>
                <a href="aboutmyanmar.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--------------------------------Payment------------------------------>
    <div class="section-2">
      <div class="container-fluid">
        <div class="d-flex justify-content-end m-4">
          <div class="d-flex flex-column">
            <h1 class="heading-1"><i class="fas fa-gem"></i> Pay Online</h1>
            <p class="para">Help grow your business by accepting all card brand payments online from your website, over the phone using a virtual terminal and via links on email invoices. Plus, access fraud screening tools and choose your payment gateway integration. 
              <br>
                <br>
              It's easy to get started
                <br>
              <br>
              Step 1: set up your Worldpay merchant account<br>
              Step 2: select product needed and pricing plan <br>
              Step 3: finish setup and start taking payments
            </p>
            
          <a href="payment.php">  <input type="button" value="Register Now " class="btn btn-danger"></a>

          </div>
        </div>
      </div>
    </div>
    <!--------------------------------------------our projects----------------------------->
    <div class="section-3">
      <div class="container text-center">
        <h1 class="heading-1">Our Projects</h1>
        <p class="para">The Yangon regional government has started providing substitute land to original
           landowners as compensation for land acquired for the New Yangon City Project on October 8.
        </p>
        <div class="row justify-content-center">
          <div class="col-md-4">
            <div class="card">
              <img src="image/datatar.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">ပျဉ်းမနား ငလိုက်ချောင်းကူးတံတား</h4>
                <p class="card-text">ပျဉ်းမနားမြို့ရှိ ငလိုက်ချောင်းကူး ၄ လမ်းသွား တံတားသစ် တည်ဆောက်နေမှုများ ၅၀ ရာခိုင်နှုန်းပြီးစီး၍ 
                  သင်္ကြန်မတိုင်မီ ၂ လမ်းသွားဖွင့်လှစ်နိုင်ရန် ဆောင်ရွက်လျက်ရှိကြောင်း သိရသည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/aya.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">ဒဂုံမြို့သစ်ဆိပ်ကမ်း</h4>
                <p class="card-text">ရန်ကုန်တိုင်းဒေသကြီးဒဂုံမြို့သစ်ဆိပ်ကမ်းပေါ်ရှိမြေ ၁,၁၀၀ ဧကကျော်တွင် Smart District စီမံကိန်းဖော်ဆောင်ရွက်နိုင်ရန်အတွက် ဆောက်လုပ်ရေးဝန်ကြီးဌာနက ဖိတ်ခေါ်ခဲ့ကြောင်း သိရသည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/satkuu.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">ပျဉ်းမနား ငလိုက်ချောင်းကူးတံတား</h4>
                <p class="card-text">ပျဉ်းမနားမြို့ရှိ ငလိုက်ချောင်းကူး ၄ လမ်းသွား တံတားသစ် တည်ဆောက်နေမှုများ ၅၀ ရာခိုင်နှုန်းပြီးစီး၍ 
                  သင်္ကြန်မတိုင်မီ ၂ လမ်းသွားဖွင့်လှစ်နိုင်ရန် ဆောင်ရွက်လျက်ရှိကြောင်း သိရသည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
        </div>
        <br>
          <br>
        <div class="row justify-content-center">
          <div class="col-md-4">
            <div class="card">
              <img src="image/mt.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">မောင်တောကညင်ချောင်းစီးပွားရေး</h4>
                <p class="card-text">မောင်တောကညင်ချောင်းစီးပွားရေးဇုန်ကို မတ်လ ၂၀ ရက်နေ့တွင် ဖွင့်လှစ်ရန် စီစဉ်ထားသော်လည်း စီမံကိန်းလုပ်ငန်းများ မပြီးပြတ်သေးသောကြောင့် ဧပြီလအတွင်း ဖွင့်လှစ်နိုင်ရန် ဆောင်ရွက်လျက်ရှိကြောင်း သိရသည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/ect.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">ရေအားလျှပ်စစ်စီမံကိန်းများ</h4>
                <p class="card-text">အရှေ့တောင်အာရှရှိ မပြီးစီးသေးသော ရေအားလျှပ်စစ်စီမံကိန်းများနှင့် ဆောက်လုပ်ရန်

                အစီအစဉ်ရှိသောရေအားလျှပ်စစ်စီမံကိန်းများ၊ အထူးသဖြင့် မဲခေါင်မြစ်တစ်လျှောက်နှင့် ဝန်းကျင်ရှိ ရေအားလျှပ်စစ်စီမံကိန်းများသည် COVID-19 ကူးစက်ရောဂါကြောင့် ရပ်တန့်သွားကြပြီ ဖြစ်သည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="image/sitt.jpg" alt="dathar" class="card-img-top">
              <div class="card-body">
                <h4 class="card-title">ပျဉ်းမနား ငလိုက်ချောင်းကူးတံတား</h4>
                <p class="card-text">ပျဉ်းမနားမြို့ရှိ ငလိုက်ချောင်းကူး ၄ လမ်းသွား တံတားသစ် တည်ဆောက်နေမှုများ ၅၀ ရာခိုင်နှုန်းပြီးစီး၍ 
                  သင်္ကြန်မတိုင်မီ ၂ လမ်းသွားဖွင့်လှစ်နိုင်ရန် ဆောင်ရွက်လျက်ရှိကြောင်း သိရသည်။
                </p>
                <a href="project.php"><input type="submit" value="Read More" class="btn btn-info"></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
<!-- ---------------------------------------------------------------------------- -->
    <div class="section-4 bg-dark">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <img src="image/timecity.jpg" alt="timecityofmyanmar" width="590">
          </div>
          <div class="col-md-5">
            <h1 class="text-white">Time City</h1>
            <p class="para-1">
              Interestingly, Times City Project which compound will be adding modern, convenient, safe remarkable living of where we establish is located in the heart of Yangon's financial district: near Hantharwaddy roundabout and Hleden bridge what's more? There is a very luxurious compound with excellent to the downtown as well as to there areas of interest within the city. Overall, Times City Project including grand hotel, office tower and residence Yatanar mall so and so is a joint venture partnership
               between Crown Advanced Construction and YCDC, intend to the highest status of country
            </p>
          </div>
        </div>
      </div>
    </div>

  </main>
<!-------------------------------footer------------------------->

  <!-- Footer -->
<footer class="page-footer font-small pt-4">

  <!-- Footer Links -->
  <div class="container text-center text-md-left">

    <!-- Grid row -->
    <div class="row">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Content -->
        <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Smart City Yangon</h5>
        <p>Yangon Government that had projects both in and at the outer rim of the city had posted all the projects in Yangon Project Bank. Of the 80 projects posted, one was an
           industrial zone by a Thai company in Dagon Myothit (East) and Dagon Myothit (South) townships..
          </p>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Links -->
        <h5 class="heading-1 font-weight-bold text-uppercase mb-4">About</h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <a href="project.php">PROJECTS</a>
            </p>
          </li>
          <li>
            <p>
              <a href="aboutmyanmar.php">ABOUT MYANMAR</a>
            </p>
          </li>
          <li>
            <p>
              <a href="payment.php">PAYMENTS</a>
            </p>
          </li>
          <li>
            <p>
              <a href="contact.php">CONTACT</a>
            </p>
          </li>
          <li>
            <p>
              <a href="about.php">ABOUT US</a>
            </p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

        <!-- Contact details -->
        <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Address</h5>

        <ul class="list-unstyled">
          <li>
            <p>
              <i class="fas fa-home mr-3"></i> Yangon,Hledan</p>
          </li>
          <li>
            <p>
              <i class="fas fa-envelope mr-3"></i>phyomaung@gmail.com</p>
          </li>
          <li>
            <p>
              <i class="fas fa-phone mr-3"></i> +959 779 252 160</p>
          </li>
        </ul>

      </div>
      <!-- Grid column -->

      <hr class="clearfix w-100 d-md-none">

      <!-- Grid column -->
      <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

        <!-- Social buttons -->
        <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Follow Us</h5>

        <!-- Facebook -->
        <a type="button" class="btn-floating btn-fb">
          <i class="fab fa-facebook-f"></i>
        </a>
        <!-- Twitter -->
        <a type="button" class="btn-floating btn-tw">
          <i class="fab fa-twitter"></i>
        </a>
        <!-- Google +-->
        <a type="button" class="btn-floating btn-gplus">
          <i class="fab fa-google-plus-g"></i>
        </a>
        <!-- Dribbble -->
        <a type="button" class="btn-floating btn-dribbble">
          <i class="fab fa-dribbble"></i>
        </a>

      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row -->

  </div>
  <!-- Footer Links -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Copyright:
    <a href="#"> Developer By Phyo Maung</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->


   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/scrollreveal"></script>
    <script>
      ScrollReveal({duration: 1000}).reveal('.site-content .d-flex')
      ScrollReveal({duration: 1000}).reveal('.section-1 .card')
      ScrollReveal({duration: 1000}).reveal('.section-2 .d-flex')
      ScrollReveal({duration: 1000}).reveal('.section-3 .card')
      ScrollReveal({duration: 1000}).reveal('.section-4 .col-md-5,.col-md-7')
    </script>

  </body>
</html>