<?php
  session_start();
  include('../connection/connection.php');
  error_reporting(1);
  if($_REQUEST['log']=='out'){
    session_destroy();
    header('location:index.php');
  }

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Admin Panel</title>
  <link rel="icon" type="image/png" href="../image/yg.png">
  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="adcss/simple-sidebar.css" rel="stylesheet">
  <script src="https://kit.fontawesome.com/860068da85.js" crossorigin="anonymous"></script>

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Yan<span style="color:#EFBAA1">Gon</span></div>
      <div class="list-group list-group-flush">
        <a href="home.php" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <a href="abmm.php" class="list-group-item list-group-item-action bg-light">About Myanmar</a>
        <a href="ad_project.php" class="list-group-item list-group-item-action bg-light">Projects</a>
        <a href="electronicbill.php" class="list-group-item list-group-item-action bg-light">Electronic Bill</a>
        <a href="taxbill.php" class="list-group-item list-group-item-action bg-light">Tax Bill</a>
        <a href="feedback.php" class="list-group-item list-group-item-action bg-light">feedback</a>
        <a href="../index.php" class="list-group-item list-group-item-action bg-light" style="color:#563D7C; font-weight:bold; font-family:'Roboto Condensed';">View Website</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Menu</button>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="#"><i class="fas fa-user"></i><?php  echo " ".$_SESSION['usr']; ?>
            
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="?log=out">Logout</a>
            </li>
          </ul>
        </div>
      </nav>
    <div class="heading">
      <h5>Categories</h5>
      <p>Welcome Admin categories</p>
    </div>
    <div class="card-columns">
        <a href="abmm.php">
        <div class="card" style="background-image:url('image/abmm.png');  background-size:cover;">
        </div>
        <h5>About Myanmar</h5>
        </a>
        <a href="ad_project.php">
        <div class="card" style="background-image:url('image/projects.jpg');  background-size:cover;">
        </div>
        <h5>Projects</h5>
        </a>
        <a href="electronicbill.php">
        <div class="card" style="background-image:url('image/elecbill.jpg');  background-size:cover;">
        </div>
        <h5>Electronic Bill</h5>
        </a>
        <a href="taxbill.php">
        <div class="card" style="background-image:url('image/taxbill.png');  background-size:cover;">
        </div>
        <h5>Tax Bill</h5>
        </a>
        <a href="user.php">
        <div class="card" style="background-image:url('image/user.png');  background-size:cover;">
        </div>
        <h5>User</h5>
        </a>
        <a href="feedback.php">
        <div class="card" style="background-image:url('image/feedback.png');  background-size:cover;">
        </div>
        <h5>Feedback</h5>
        </a>
    </div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
