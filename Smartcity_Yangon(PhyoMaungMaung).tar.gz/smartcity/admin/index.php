<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Admin Login</title>
        
        <link rel="icon" type="image/png" href="../image/yg.png">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
		<script src="https://kit.fontawesome.com/860068da85.js" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="css/login.css">
    </head>
    <body>
    <h3 text-align="center" class="logintitle">Login</h3>
    <div class="container">

  <div class="row">
    
	<?php
		session_start();
		include("../connection/connection.php");
		error_reporting(1);
		if(isset($_REQUEST['log'])){
			$user = $_REQUEST['user'];
			$pass = $_REQUEST['pass'];
			$sq = mysql_query("SELECT user_email,user_pass FROM user_ad WHERE user_email='$user'");
			$r = mysql_fetch_array($sq);
			if(($r['user_email']==$user) && ($r['user_pass']==$pass)){
				$_SESSION['usr'] = $_REQUEST['user'];
				header('location:home.php');
			}
			else{
        
        echo "<script>alert('Wrong username or password')</script>";
			}
		}

	?>

    <div class="main">
      <h3>Please Log In, or <a href="signup.php">Sign Up</a></h3>
      <div class="row">
        <div class="col-xs-6 col-sm-6 col-md-6">
          <a href="#" class="btn btn-lg btn-primary btn-block">Facebook</a>
        </div>
        <div class="col-xs-6 col-sm-6 col-md-6">
          <a href="#" class="btn btn-lg btn-info btn-block">Google</a>
        </div>
      </div>
      <div class="login-or">
        <hr class="hr-or">
        <span class="span-or">or</span>
      </div>

      <form role="form">
        <div class="form-group">
          <label for="inputUsernameEmail">Username or email</label>
          <input type="text" name="user" required class="form-control" id="inputUsernameEmail">
        </div>
        <div class="form-group">
          <a class="pull-right" href="#">Forgot password?</a>
          <label for="inputPassword">Password</label>
          <input type="password" name="pass" required class="form-control" id="inputPassword">
        </div>
        <div class="checkbox pull-right">
          <label>
            <input type="checkbox">
            Remember me </label>
        </div>
        <button type="submit" name="log" class="btn btn btn-primary">
          Log In
        </button>
      </form>
    
    </div>
    
  </div>
</div>
    </body>
</html>