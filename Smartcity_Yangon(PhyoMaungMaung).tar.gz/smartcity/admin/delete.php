<?php
    include("../connection/connection.php");
    error_reporting(1);
    
    $id = $_REQUEST['id'];
    $query = "DELETE FROM info WHERE id=$id";
    $result = mysql_query($query) or die('Delete Fail..');
    header('location:abmm.php');
?>