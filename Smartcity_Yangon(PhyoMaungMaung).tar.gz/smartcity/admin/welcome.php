<?php
    error_reporting(1);
    include("../connection/connection.php");
    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <link rel="icon" type="image/ong" href="../image/yg.png">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="css/signup.css">
</head>
<body>
<div class="container">
<?php
if(isset($_POST['register'])){
        $user_first = $_POST['namef'];
        $user_last= $_POST['names'];
        $user_email= $_POST['email'];
        $user_pass = $_POST['pass'];
        $user_birthday = $_POST['day'].'/'.$_POST['month'].'/'.$_POST['year'];
        $user_phone = $_POST['phone'];
        $user_gender = $_POST['sex'];
        $rs = mysql_query("SELECT * FROM user_ad WHERE user_email='$user_email'");
        if(mysql_num_rows($rs)>0){

            $err = "Your email is already exists.!";
            exit;
        }
        $sql="INSERT INTO user_ad(user_first,user_last,user_email,user_pass,user_birthday,user_phone,user_gender)
                        VALUES('$user_first','$user_last','$user_email','$user_pass','$user_birthday','$user_phone','$user_gender')";
        $rs =mysql_query($sql) or die("Fail Query.. ");


}
?>
            <h3>Welcome <span style="color:black">
                        <?php                   
                            echo $user_first.''.$user_last;
                        ?>
                        </span>
            </h3><br/>
            <h5>Your Email is <span style="color:black">
                                    <?php
                                     echo $user_email;
                                    ?>
                              </span>
            </h5>   
            <p>Your Account is successfully created . </p> <br/>
            <a href="index.php">Login</a> 
        </div> <!-- ./container -->

        
</body>
</html>