<?php
    include("../connection/connection.php");
    error_reporting(1);
    
    $id = $_REQUEST['id'];
    $query = "DELETE FROM user_ad WHERE id=$id";
    $result = mysql_query($query) or die('Delete Fail..');
    header('location:user.php');
?>