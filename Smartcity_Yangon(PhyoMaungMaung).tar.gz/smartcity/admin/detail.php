<?php
    include('../connection/connection.php');
    error_reporting(1);

    $name = $_GET['name'];
    $email = $_GET['email'];
    $pass = $_GET['pass'];
    $mobile = $_GET['mobile'];

    $ins = "INSERT INTO user VALUES('','$name','$email','$pass','$mobile')";
    mysql_query($ins);
    mysql_close();
?>
