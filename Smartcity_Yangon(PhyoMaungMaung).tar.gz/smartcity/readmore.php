<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/860068da85.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style.css">

  <title>Smart city</title>
</head>
<body>

  <!-------------------------------------Menu Navbar--------------------------------->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
      <a href="index.php" class="navbar-brand ml-3" >Yan<span style="color:#EFBAA1">Gon</span></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu" 
      aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse"></div>
      <div class="collapse navbar-collapse" id="navbarMenu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
              <a href="aboutmyanmar.php" class="nav-link">About Myanmar</a>
          </li>
          <li class="nav-item">
              <a href="project.php" class="nav-link">Projects</a>
          </li>
          <li class="nav-item">
            <a href="payment.php" class="nav-link">Payments</a>
          </li>
          <li class="nav-item">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
          <li class="nav-item">
            <a href="about.php" class="nav-link">About Us</a>
          </li>
        </ul>

        <?php
                    include('connection/connection.php');
                    if(isset($_POST['sub'])){
                      $sub_email = $_POST['email'];
                      if(mysql_query("INSERT INTO subscribe VALUES('','$sub_email')")){

                        echo "<script>alert('Thank for your Subscribe')</script>";
                      }
                      else{
                        echo "<script>alert('Fail your subscribe')</script>";
                      }
                    }

                ?>
              <form class="form-inline my-2 my-lg-0" method="post">
              
                  <input type="email" name="email" value="" placeholder="Email" required>
                  <button type="submit" name="sub" id="" class="btn btn-danger" btn-lg btn-block">SUBSCRIBE</button>
              </form>
      </div>
    </nav>
  </header>

  <!----------------------------- project view ------------------------------------->
  
  <br/>
  <div class="container">  
    <h4 align="center">PROJECT NEWS</h4>
    <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Home</a></li>
      <li class="breadcrumb-item"><a href="project.php">Projects</a></li>
      <li class="breadcrumb-item active" aria-current="page">Details</li>
    </ol>
   </nav>
    


            <?php
                include('connection/connection.php');
                error_reporting(1);
                if(isset($_GET['id'])){
                    $pj_id = $_GET['id'];
                    $sql = "SELECT * FROM project WHERE id='$pj_id'";
                    $r = mysql_query($sql);
                    while($row=mysql_fetch_array($r)){
                        $pj_id = $row['id'];
                        $pj_title = $row['pj_title'];
                        $pj_desp = $row['pj_desp'];
                        $pj_image = $row['pj_image'];

            ?>
            <div class="header-read">
                      <h5><?php  echo $pj_title; ?></h5>
            </div>
            <div class="photo-read">
                      <img src="./admin/project/<?php echo $pj_image; ?>" class="border border-danger" alt="project_myanmar">
            </div>
            <div class="read-p">
                      <?php   echo $pj_desp;  ?>
            </div>
                <a href="project.php">  <button type="button" class="btn btn-danger">Back</button></a>      
            <?php
                    }
                }
            ?>
            
           

  </div>
<!-------------------------------footer------------------------->

   <!-- Footer -->
<footer class="page-footer font-small pt-4">

<!-- Footer Links -->
<div class="container text-center text-md-left">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Content -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Smart City Yangon</h5>
      <p>Yangon Government that had projects both in and at the outer rim of the city had posted all the projects in Yangon Project Bank. Of the 80 projects posted, one was an
         industrial zone by a Thai company in Dagon Myothit (East) and Dagon Myothit (South) townships..
        </p>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Links -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">About</h5>

      <ul class="list-unstyled">
        <li>
          <p>
            <a href="project.php">PROJECTS</a>
          </p>
        </li>
        <li>
          <p>
            <a href="aboutmyanmar.php">ABOUT MYANMAR</a>
          </p>
        </li>
        <li>
          <p>
            <a href="payment.php">PAYMENTS</a>
          </p>
        </li>
        <li>
          <p>
            <a href="contact.php">CONTACT</a>
          </p>
        </li>
        <li>
          <p>
            <a href="about.php">ABOUT US</a>
          </p>
        </li>
      </ul>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Contact details -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Address</h5>

      <ul class="list-unstyled">
        <li>
          <p>
            <i class="fas fa-home mr-3"></i> Yangon,Hledan</p>
        </li>
        <li>
          <p>
            <i class="fas fa-envelope mr-3"></i>phyomaung@gmail.com</p>
        </li>
        <li>
          <p>
            <i class="fas fa-phone mr-3"></i> +959 779 252 160</p>
        </li>
      </ul>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

      <!-- Social buttons -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Follow Us</h5>

      <!-- Facebook -->
      <a type="button" class="btn-floating btn-fb">
        <i class="fab fa-facebook-f"></i>
      </a>
      <!-- Twitter -->
      <a type="button" class="btn-floating btn-tw">
        <i class="fab fa-twitter"></i>
      </a>
      <!-- Google +-->
      <a type="button" class="btn-floating btn-gplus">
        <i class="fab fa-google-plus-g"></i>
      </a>
      <!-- Dribbble -->
      <a type="button" class="btn-floating btn-dribbble">
        <i class="fab fa-dribbble"></i>
      </a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</div>
<!-- Footer Links -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <a href="#"> Developer By Phyo Maung</a>
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->


   <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    <script src="https://unpkg.com/scrollreveal"></script>

    <script>
      ScrollReveal({duration: 1000}).reveal('.site-content .d-flex')
      ScrollReveal({duration: 1000}).reveal('.section-1 .card')
      ScrollReveal({duration: 1000}).reveal('.section-2 .d-flex')
      ScrollReveal({duration: 1000}).reveal('.section-3 .card')
      ScrollReveal({duration: 1000}).reveal('.section-4 .col-md-5,.col-md-7')
    </script>

  </body>
</html>