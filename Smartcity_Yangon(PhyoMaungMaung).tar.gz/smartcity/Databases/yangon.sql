-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 20, 2020 at 01:59 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yangon`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(6) UNSIGNED NOT NULL,
  `ct_name` text NOT NULL,
  `ct_email` varchar(50) NOT NULL,
  `ct_sub` text NOT NULL,
  `ct_massage` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `ct_name`, `ct_email`, `ct_sub`, `ct_massage`) VALUES
(1, 'phyo', 'phyo@gmail.com', 'webstie info', 'Need More Information'),
(2, 'phyo', 'phyo@gmail.com', 'webstie info', 'Need More Information');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `id` int(6) UNSIGNED NOT NULL,
  `mm_title` text NOT NULL,
  `mm_desp` varchar(255) NOT NULL,
  `mm_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`id`, `mm_title`, `mm_desp`, `mm_image`) VALUES
(2, 'National Symbols', 'The yellow, green and red colours included as background colours indicate the three-coloured flag which was applied magnificently in the period of struggle for the independence of Myanmar ', 'national.jpg'),
(3, 'Geography', 'Myanmar, a republic in South-East Asia, bounded on the north by Tibet Autonomous Region of China; on the east by China, Laos, and Thailand; on the south by the Andaman Sea and the Bay of Bengal ', 'geography.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `meterbill`
--

CREATE TABLE `meterbill` (
  `id` int(6) UNSIGNED NOT NULL,
  `meterbillno` int(10) NOT NULL,
  `meteramount` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meterbill`
--

INSERT INTO `meterbill` (`id`, `meterbillno`, `meteramount`) VALUES
(1, 2147483647, 2000),
(2, 2147483647, 1500),
(3, 2147483647, 1500),
(4, 545646795, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(6) UNSIGNED NOT NULL,
  `pj_title` text NOT NULL,
  `pj_desp` text NOT NULL,
  `pj_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `project`
--

INSERT INTO `project` (`id`, `pj_title`, `pj_desp`, `pj_image`) VALUES
(1, 'á€’á€‚á€¯á€¶á€™á€¼á€­á€¯á€·á€žá€…á€ºá€†á€­á€•á€ºá€€á€™á€ºá€¸á€á€½á€„á€º Smart District á€…á€®á€™á€¶á€€á€­á€”á€ºá€¸', 'á€•á€»á€‰á€ºá€¸á€™á€”á€¬á€¸á€™á€¼á€­á€¯á€·á€›á€¾á€­ á€„á€œá€­á€¯á€€á€ºá€á€»á€±á€¬á€„á€ºá€¸á€€á€°á€¸ á„ á€œá€™á€ºá€¸á€žá€½á€¬á€¸ á€á€¶á€á€¬á€¸á€žá€…á€º á€á€Šá€ºá€†á€±á€¬á€€á€ºá€”á€±á€™á€¾á€¯á€™á€»á€¬á€¸ á…á€ á€›á€¬á€á€­á€¯á€„á€ºá€”á€¾á€¯á€”á€ºá€¸á€•á€¼á€®á€¸á€…á€®á€¸á á€žá€„á€ºá€¹á€€á€¼á€”á€ºá€™á€á€­á€¯á€„á€ºá€™á€® á‚ á€œá€™á€ºá€¸á€žá€½á€¬á€¸á€–á€½á€„á€·á€ºá€œá€¾á€…á€ºá€”á€­á€¯á€„á€ºá€›á€”á€º á€†á€±á€¬á€„á€ºá€›á€½á€€á€ºá€œá€»á€€á€ºá€›á€¾á€­á€€á€¼á€±á€¬á€„á€ºá€¸ á€žá€­á€›á€žá€Šá€ºá‹ ', 'pj1.jpg'),
(2, 'á€™á€±á€¬á€„á€ºá€á€±á€¬á€€á€Šá€„á€ºá€á€»á€±á€¬á€„á€ºá€¸á€…á€®á€¸á€•á€½á€¬á€¸á€›á€±á€¸á€‡á€¯á€”á€º á€…á€®á€™á€¶á€€á€­á€”á€ºá€¸á€á€Šá€ºá€†á€±á€¬á€€á€ºá€á€¼á€„á€ºá€¸á€œá€¯á€•á€ºá€„á€”á€ºá€¸á€™á€»á€¬á€¸', 'á€•á€»á€‰á€ºá€¸á€™á€”á€¬á€¸á€™á€¼á€­á€¯á€·á€›á€¾á€­ á€„á€œá€­á€¯á€€á€ºá€á€»á€±á€¬á€„á€ºá€¸á€€á€°á€¸ á„ á€œá€™á€ºá€¸á€žá€½á€¬á€¸ á€á€¶á€á€¬á€¸á€žá€…á€º á€á€Šá€ºá€†á€±á€¬á€€á€ºá€”á€±á€™á€¾á€¯á€™á€»á€¬á€¸ á…á€ á€›á€¬á€á€­á€¯á€„á€ºá€”á€¾á€¯á€”á€ºá€¸á€•á€¼á€®á€¸á€…á€®á€¸á á€žá€„á€ºá€¹á€€á€¼á€”á€ºá€™á€á€­á€¯á€„á€ºá€™á€® á‚ á€œá€™á€ºá€¸á€žá€½á€¬á€¸á€–á€½á€„á€·á€ºá€œá€¾á€…á€ºá€”á€­á€¯á€„á€ºá€›á€”á€º á€†á€±á€¬á€„á€ºá€›á€½á€€á€ºá€œá€»á€€á€ºá€›á€¾á€­á€€á€¼á€±á€¬á€„á€ºá€¸ á€žá€­á€›á€žá€Šá€ºá‹ ', 'pj2.jpg'),
(4, 'á€¡á€›á€¾á€±á€·á€á€±á€¬á€„á€ºá€¡á€¬á€›á€¾á€›á€¾á€­ á€›á€±á€¡á€¬á€¸á€œá€»á€¾á€•á€ºá€…á€…á€ºá€…á€®á€™á€¶á€€á€­á€”á€ºá€¸á€™á€»á€¬á€¸ á€›á€•á€ºá€†á€­á€¯á€„á€ºá€¸ ', 'á€¡á€›á€¾á€±á€·á€á€±á€¬á€„á€ºá€¡á€¬á€›á€¾á€›á€¾á€­ á€™á€•á€¼á€®á€¸á€…á€®á€¸á€žá€±á€¸á€žá€±á€¬ á€›á€±á€¡á€¬á€¸á€œá€»á€¾á€•á€ºá€…á€…á€ºá€…á€®á€™á€¶á€€á€­á€”á€ºá€¸á€™á€»á€¬á€¸á€”á€¾á€„á€·á€º á€†á€±á€¬á€€á€ºá€œá€¯á€•á€ºá€›á€”á€º\r\n\r\ná€¡á€…á€®á€¡á€…á€‰á€ºá€›á€¾á€­á€žá€±á€¬á€›á€±á€¡á€¬á€¸á€œá€»á€¾á€•á€ºá€…á€…á€ºá€…á€®á€™á€¶á€€á€­á€”á€ºá€¸á€™á€»á€¬á€¸áŠ á€¡á€‘á€°á€¸á€žá€–á€¼á€„á€·á€º á€™á€²á€á€±á€«á€„á€ºá€™á€¼á€…á€ºá€á€…á€ºá€œá€»á€¾á€±á€¬á€€á€ºá€”á€¾á€„á€·á€º á€á€”á€ºá€¸á€€á€»á€„á€ºá€›á€¾á€­ á€›á€±á€¡á€¬á€¸á€œá€»á€¾á€•á€ºá€…á€…á€ºá€…á€®á€™á€¶á€€á€­á€”á€ºá€¸á€™á€»á€¬á€¸á€žá€Šá€º COVID-19 á€€á€°á€¸á€…á€€á€ºá€›á€±á€¬á€‚á€«á€€á€¼á€±á€¬á€„á€·á€º á€›á€•á€ºá€á€”á€·á€ºá€žá€½á€¬á€¸á€€á€¼á€•á€¼á€® á€–á€¼á€…á€ºá€žá€Šá€ºá‹', '8e0b77fbc9ff40024476dada4337e4e5_L.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `subscribe`
--

CREATE TABLE `subscribe` (
  `id` int(6) UNSIGNED NOT NULL,
  `sub_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscribe`
--

INSERT INTO `subscribe` (`id`, `sub_email`) VALUES
(1, 'koko@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `taxbill`
--

CREATE TABLE `taxbill` (
  `id` int(6) UNSIGNED NOT NULL,
  `taxno` int(10) NOT NULL,
  `taxbank` int(20) NOT NULL,
  `taxname` text NOT NULL,
  `taxaddress` varchar(50) NOT NULL,
  `taxamount` int(20) NOT NULL,
  `taxemail` varchar(50) NOT NULL,
  `taxphone` int(20) NOT NULL,
  `taxtype` text NOT NULL,
  `taxpaytype` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxbill`
--

INSERT INTO `taxbill` (`id`, `taxno`, `taxbank`, `taxname`, `taxaddress`, `taxamount`, `taxemail`, `taxphone`, `taxtype`, `taxpaytype`) VALUES
(1, 7897879, 2147483647, 'maung', 'yangon', 2000, 'maung@gmmail.com', 9874545, 'CapitalGains', 'AdvancedMonthlyPayment');

-- --------------------------------------------------------

--
-- Table structure for table `title`
--

CREATE TABLE `title` (
  `id` int(6) UNSIGNED NOT NULL,
  `title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `title`
--

INSERT INTO `title` (`id`, `title`) VALUES
(1, 'History'),
(2, 'National'),
(3, 'Geography'),
(4, 'People'),
(5, 'Culture'),
(6, 'Travel');

-- --------------------------------------------------------

--
-- Table structure for table `user_ad`
--

CREATE TABLE `user_ad` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_first` varchar(50) NOT NULL,
  `user_last` varchar(50) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_pass` varchar(50) NOT NULL,
  `user_birthday` varchar(50) NOT NULL,
  `user_phone` bigint(20) NOT NULL,
  `user_gender` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_ad`
--

INSERT INTO `user_ad` (`id`, `user_first`, `user_last`, `user_email`, `user_pass`, `user_birthday`, `user_phone`, `user_gender`) VALUES
(1, 'phyo', 'maung', 'phyomaung@gmail.com', 'phyomaung123', '20/20/1996', 9779252160, 'Male'),
(2, 'maung', 'ko', 'maung@gmail.com', 'maung123', '20/6/1996', 9779252160, 'Male'),
(3, 'maung', 'maung', 'maungmaung@gmail.com', 'maung123', '20/6/1996', 9779252160, 'Female'),
(4, 'ko', 'ko', 'koko@gmail.com', 'koko123', '20/6/1996', 9779252160, 'Male'),
(7, 'maung', 'ko', 'zxozwe99@gmail.com', 'phyo123', '10/6/1996', 9779252160, 'Male'),
(8, 'hla', 'hla', 'hlahla@gmail.com', 'hla123', '14/5/1989', 9779252160, 'Female');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meterbill`
--
ALTER TABLE `meterbill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribe`
--
ALTER TABLE `subscribe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taxbill`
--
ALTER TABLE `taxbill`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title`
--
ALTER TABLE `title`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_ad`
--
ALTER TABLE `user_ad`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `meterbill`
--
ALTER TABLE `meterbill`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `subscribe`
--
ALTER TABLE `subscribe`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `taxbill`
--
ALTER TABLE `taxbill`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `title`
--
ALTER TABLE `title`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_ad`
--
ALTER TABLE `user_ad`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
