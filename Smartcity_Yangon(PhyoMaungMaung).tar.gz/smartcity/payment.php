<?php
    error_reporting(1);
    include("connection/connection.php"); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <!-- Bootstrap CSS -->
  <link rel="icon" type="image/png" href="image/yg.png">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <script src="https://kit.fontawesome.com/860068da85.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="style.css">

  <title>Payments</title>
</head>
<body>

  <!-------------------------------------Menu Navbar--------------------------------->
  <header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top">
      <a href="index.php" class="navbar-brand ml-3" >Yan<span style="color:#EFBAA1">Gon</span></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarMenu" 
      aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle Navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

      <div class="collapse navbar-collapse"></div>
      <div class="collapse navbar-collapse" id="navbarMenu">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
              <a href="aboutmyanmar.php" class="nav-link">About Myanmar</a>
          </li>
          <li class="nav-item">
              <a href="project.php" class="nav-link">Projects</a>
          </li>
          <li class="nav-item">
            <a href="payment.php" class="nav-link">Payments</a>
          </li>
          <li class="nav-item">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
          <li class="nav-item">
            <a href="about.php" class="nav-link">About Us</a>
          </li>
        </ul>

        <?php
                    include('connection/connection.php');
                    if(isset($_POST['sub'])){
                      $sub_email = $_POST['email'];
                      if(mysql_query("INSERT INTO subscribe VALUES('','$sub_email')")){

                        echo "<script>alert('Thank for your Subscribe')</script>";
                      }
                      else{
                        echo "<script>alert('Fail your subscribe')</script>";
                      }
                    }

                ?>
              <form class="form-inline my-2 my-lg-0" method="post">
              
                  <input type="email" name="email" value="" placeholder="Email" required>
                  <button type="submit" name="sub" id="" class="btn btn-danger" btn-lg btn-block">SUBSCRIBE</button>
              </form>

      </div>
    </nav>
  </header>
<!-------------------------------------------payment --------------------------- -->

<div class="pay">
  <div class="payment">
  </div>
  <nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">Payments</li>
  </ol>
  </nav>
  <br/>
  <div class="container">
      <span>Bill Payments</span>
      <hr/>
      <p>Save your time and energy by paying your bills conveniently with our bill payment solutions.</p>

  </div>
  <div class="container">
      <p class="txt">WHAT YOU CAN PAY FOR</p>
      <div class="list">
        <ul>
          <li><span>Meter bills</span></li>
          <li><span>Tax payments</span></li>
          <li><span>Life-insurance premium</span></li>
          <li><span>Share-premium payment</span></li>
        </ul>
      </div>
    </p>
      <button class="btn btn-success" type="button" data-toggle="collapse" data-target="#meterbill" aria-expanded="false" aria-controls="collapseExample">
          Meter Bill
      </button>
      <button class="btn btn-success" type="button" data-toggle="collapse" data-target="#taxbill" aria-expanded="false" aria-controls="collapseExample">
          Tax Bill
      </button>
    </p>
      <div class="collapse" id="meterbill">
        <div class="card card-body">
        <?php

              if(isset($_POST['meterpay'])){

                  $meterbillno = $_POST['meterbillno'];
                  $meteramount = $_POST['meteramount'];
                  if(mysql_query("INSERT INTO meterbill VALUES('','$meterbillno','$meteramount')")){

                    echo "<script>alert('Successfully meter bill payments')</script>";
                }
                else{

                    echo "<script>alert('Sorry please check your bill payment.!')</script>";
                }

              }
        ?>
        <form method="post">
          <h5 text-align="center" style="color:#0e67b5;"><b>Meter Bill Payments</b></h5>
          <div class="form-group">
            <label for="billNumber">Bill Number</label>
            <input type="number" name="meterbillno" class="form-control" id="billnumber" aria-describedby="emailHelp" placeholder="eg. 1208543164">
            <small id="emailHelp" class="form-text text-muted"><b>Bill Number ဆိုသည်မှာ.?</b>ဓာတ်အားခတောင်းခံလွှာရှိ "ကွန်ပြူတာစာရင်းအမှတ်" ကိုဆိုလိုခြင်းဖြစ်သည်။</small>
          </div>
          <div class="form-group">
            <label for="amount">Amount (MMK)</label>
            <input type="number" name="meteramount" class="form-control" id="amount" placeholder="1500">
          </div>
          <button type="submit" name="meterpay" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div><div class="collapse" id="taxbill">
        <div class="card card-body">
        <?php
            
            if(isset($_POST['taxpay'])){

              $taxno = $_POST['taxno'];
              $taxbank  = $_POST['taxbank'];
              $taxname = $_POST['taxname'];
              $taxaddress = $_POST['taxaddress'];
              $taxamount = $_POST['taxamount'];
              $taxemail = $_POST['taxemail'];
              $taxphone = $_POST['taxphone'];
              $taxtype = $_POST['taxtype'];
              $taxpaytype  = $_POST['taxpaytype'];

              if(mysql_query("INSERT INTO taxbill VALUES('','$taxno','$taxbank','$taxname','$taxaddress',
                              '$taxamount','$taxemail','$taxphone','$taxtype','$taxpaytype')")){

                                echo "<script>alert('Success your payment')</script>";
                              }
                              else{

                                echo "<script>alert('Sorry check info')</script>";
                              }
            }

        ?>

        <form method="post">
        <h5 text-align="center" style="color:#0e67b5;"><b>Tax Payments</b></h5>
            <div class="form-group">
              <label for="taxnumber">TIN (Tax Payer Identification Number)</label>
              <input type="number" name="taxno" class="form-control" id="taxnumber">
            </div>
            <div class="form-group">
              <label for="bank">Settlement Bank</label>
              <input type="number" name="taxbank" class="form-control" id="bank">
            </div>
            <div class="form-group">
              <label for="name">Name (English Only)</label>
              <input type="text" name="taxname" class="form-control" id="name">
            </div>
            <div class="form-group">
              <label for="address">Address (English Only)</label>
              <input type="text" name="taxaddress" class="form-control" id="address">
            </div>
            <div class="form-group">
              <label for="taxamount">Tax Amount (Kyats, 2 decimals)</label>
              <input type="number" name="taxamount" class="form-control" id="taxamount">
            </div>
            <div class="form-group">
              <label for="taxemail">Contact Email</label>
              <input type="email" name="taxemail" class="form-control" id="taxemail">
            </div>
            <div class="form-group">
              <label for="taxphone">Contact Phone (Numbers only)</label>
              <input type="tel" name="taxphone" class="form-control" id="taxphone">
            </div>
            <div class="form-group">
              <label for="taxtype">Tax Type</label>
              <select name="taxtype" class="form-control" id="taxtype">
                <option value="CapitalGains">(CG)Capital Gains</option>
                <option value="CommercialTax">(CT)Commercial Tax</option>
                <option value="IncomeTax">(IT)Income Tax</option>
                <option value="SpecificGoodTax">(SGT)Specific Good Tax</option>
              </select>
            </div>
            <div class="form-group">
              <label for="taxpaytype">Payment Type</label>
              <select name="taxpaytype" class="form-control" id="taxpaytype">
                <option value="AdvancedMonthlyPayment">Advanced Monthly Payment</option>
                <option value="AuditAssessment">Audit Assessment</option>
                <option value="BalanceDuewithReturn">Balance Due with Return</option>
              </select>
            </div>
            <button type="submit" name="taxpay" class="btn btn-primary">Submit</button>
        </form>
        </div>
      </div>
      <hr/>
  </div>
</div>
    <!-- Footer -->
<footer class="page-footer font-small pt-4">

<!-- Footer Links -->
<div class="container text-center text-md-left">

  <!-- Grid row -->
  <div class="row">

    <!-- Grid column -->
    <div class="col-md-4 col-lg-3 mr-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Content -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Smart City Yangon</h5>
      <p>Yangon Government that had projects both in and at the outer rim of the city had posted all the projects in Yangon Project Bank. Of the 80 projects posted, one was an
         industrial zone by a Thai company in Dagon Myothit (East) and Dagon Myothit (South) townships..
        </p>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-2 col-lg-2 mx-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Links -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">About</h5>

      <ul class="list-unstyled">
        <li>
          <p>
            <a href="project.php">PROJECTS</a>
          </p>
        </li>
        <li>
          <p>
            <a href="aboutmyanmar.php">ABOUT MYANMAR</a>
          </p>
        </li>
        <li>
          <p>
            <a href="payment.php">PAYMENTS</a>
          </p>
        </li>
        <li>
          <p>
            <a href="contact.php">CONTACT</a>
          </p>
        </li>
        <li>
          <p>
            <a href="about.php">ABOUT US</a>
          </p>
        </li>
      </ul>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-4 col-lg-3 mx-auto my-md-4 my-0 mt-4 mb-1">

      <!-- Contact details -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Address</h5>

      <ul class="list-unstyled">
        <li>
          <p>
            <i class="fas fa-home mr-3"></i> Yangon,Hledan</p>
        </li>
        <li>
          <p>
            <i class="fas fa-envelope mr-3"></i>phyomaung@gmail.com</p>
        </li>
        <li>
          <p>
            <i class="fas fa-phone mr-3"></i> +959 779 252 160</p>
        </li>
      </ul>

    </div>
    <!-- Grid column -->

    <hr class="clearfix w-100 d-md-none">

    <!-- Grid column -->
    <div class="col-md-2 col-lg-2 text-center mx-auto my-4">

      <!-- Social buttons -->
      <h5 class="heading-1 font-weight-bold text-uppercase mb-4">Follow Us</h5>

      <!-- Facebook -->
      <a type="button" class="btn-floating btn-fb">
        <i class="fab fa-facebook-f"></i>
      </a>
      <!-- Twitter -->
      <a type="button" class="btn-floating btn-tw">
        <i class="fab fa-twitter"></i>
      </a>
      <!-- Google +-->
      <a type="button" class="btn-floating btn-gplus">
        <i class="fab fa-google-plus-g"></i>
      </a>
      <!-- Dribbble -->
      <a type="button" class="btn-floating btn-dribbble">
        <i class="fab fa-dribbble"></i>
      </a>

    </div>
    <!-- Grid column -->

  </div>
  <!-- Grid row -->

</div>
<!-- Footer Links -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2020 Copyright:
  <a href="#"> Developer By Phyo Maung</a>
</div>
<!-- Copyright -->

</footer>
<!-- Footer -->



 <!-- Optional JavaScript -->
  <!-- jQuery first, then Popper.js, then Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="https://unpkg.com/scrollreveal"></script>

  <script>
    ScrollReveal({duration: 1000}).reveal('.site-content .d-flex')
    ScrollReveal({duration: 1000}).reveal('.section-1 .card')
    ScrollReveal({duration: 1000}).reveal('.section-2 .d-flex')
    ScrollReveal({duration: 1000}).reveal('.section-3 .card')
    ScrollReveal({duration: 1000}).reveal('.section-4 .col-md-5,.col-md-7')
  </script>

</body>
</html>